import React from 'react'

function DetailPage() {
  return (
    <div className='container mt-4'>
      <h1>Product Detail Page</h1>
    </div>
  )
}

export default DetailPage