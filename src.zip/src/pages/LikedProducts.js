import React from "react";
import Products from "./../components/Products";

function LikedProducts() {
  return (
    <div className="container mt-4">
      <h2>Liked Products</h2>
    </div>
  );
}

export default LikedProducts;
